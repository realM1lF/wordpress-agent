<?php

namespace Levi\Agent\Memory;

use WP_Error;

class VectorStore {
    private string $dbPath;
    private ?\SQLite3 $db = null;
    private string $embeddingModel = 'text-embedding-3-small';
    private int $embeddingDimensions = 1536;

    public function __construct() {
        $this->dbPath = LEVI_AGENT_PLUGIN_DIR . 'data/vector-memory.sqlite';
        $this->init();
    }

    public function isAvailable(): bool {
        return $this->db !== null;
    }

    private function init(): void {
        if (!class_exists('\SQLite3')) {
            error_log('Levi Agent: SQLite3 PHP extension not available. Vector memory disabled.');
            return;
        }

        $dataDir = dirname($this->dbPath);
        if (!is_dir($dataDir)) {
            wp_mkdir_p($dataDir);
        }
        if (!is_dir($dataDir) || !is_writable($dataDir)) {
            error_log('Levi Agent: data directory not writable: ' . $dataDir);
            return;
        }

        try {
            $this->db = new \SQLite3($this->dbPath);
            $this->db->enableExceptions(true);
            $this->createTables();
        } catch (\Throwable $e) {
            error_log('Levi Agent: SQLite3 init failed: ' . $e->getMessage());
            $this->db = null;
        }
    }

    private function createTables(): void {
        $this->db->exec('
            CREATE TABLE IF NOT EXISTS memory_vectors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_file VARCHAR(255),
                content TEXT NOT NULL,
                embedding BLOB NOT NULL,
                memory_type VARCHAR(50) NOT NULL,
                chunk_index INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ');

        $this->db->exec('
            CREATE INDEX IF NOT EXISTS idx_memory_type ON memory_vectors(memory_type)
        ');

        $this->db->exec('
            CREATE TABLE IF NOT EXISTS episodic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                fact TEXT NOT NULL,
                embedding BLOB NOT NULL,
                context VARCHAR(255),
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ');

        $this->db->exec('
            CREATE TABLE IF NOT EXISTS loaded_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path VARCHAR(500) UNIQUE NOT NULL,
                file_hash VARCHAR(64) NOT NULL,
                loaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ');
    }

    /**
     * Generate embedding via configured provider (OpenRouter/OpenAI).
     */
    public function generateEmbedding(string $text): array|WP_Error {
        $config = $this->getEmbeddingRequestConfig();
        if (is_wp_error($config)) {
            return $config;
        }

        $text = substr($text, 0, 8000);

        $response = wp_remote_post($config['endpoint'], [
            'headers' => $config['headers'],
            'body' => json_encode([
                'input' => $text,
                'model' => $config['model'],
            ]),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        if ($statusCode !== 200) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $error = $body['error']['message'] ?? ('Embedding generation failed (' . $config['provider'] . ')');
            return new WP_Error('embedding_failed', $error);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['data'][0]['embedding'] ?? [];
    }

    public function storeVector(
        string $content,
        array $embedding,
        string $memoryType,
        string $sourceFile = '',
        int $chunkIndex = 0
    ): bool {
        if (!$this->db) {
            return false;
        }

        try {
            $stmt = $this->db->prepare('
                INSERT INTO memory_vectors (source_file, content, embedding, memory_type, chunk_index)
                VALUES (:source_file, :content, :embedding, :memory_type, :chunk_index)
            ');

            $stmt->bindValue(':source_file', $sourceFile, SQLITE3_TEXT);
            $stmt->bindValue(':content', $content, SQLITE3_TEXT);
            $stmt->bindValue(':embedding', json_encode($embedding), SQLITE3_BLOB);
            $stmt->bindValue(':memory_type', $memoryType, SQLITE3_TEXT);
            $stmt->bindValue(':chunk_index', $chunkIndex, SQLITE3_INTEGER);

            $stmt->execute();
            return true;
        } catch (\Exception $e) {
            error_log('VectorStore error: ' . $e->getMessage());
            return false;
        }
    }

    public function storeEpisodicMemory(
        string $fact,
        array $embedding,
        ?int $userId = null,
        string $context = ''
    ): bool {
        if (!$this->db) {
            return false;
        }

        try {
            $stmt = $this->db->prepare('
                INSERT INTO episodic_memory (user_id, fact, embedding, context)
                VALUES (:user_id, :fact, :embedding, :context)
            ');

            $stmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
            $stmt->bindValue(':fact', $fact, SQLITE3_TEXT);
            $stmt->bindValue(':embedding', json_encode($embedding), SQLITE3_BLOB);
            $stmt->bindValue(':context', $context, SQLITE3_TEXT);

            $stmt->execute();
            return true;
        } catch (\Exception $e) {
            error_log('VectorStore error: ' . $e->getMessage());
            return false;
        }
    }

    public function searchSimilar(
        array $queryEmbedding,
        string $memoryType = '',
        int $limit = 5,
        float $minSimilarity = 0.7
    ): array {
        if (!$this->db) {
            return [];
        }

        $sql = 'SELECT id, content, embedding, memory_type, source_file FROM memory_vectors';

        if ($memoryType) {
            $sql .= ' WHERE memory_type = :memory_type';
        }

        $stmt = $this->db->prepare($sql);
        
        if ($memoryType) {
            $stmt->bindValue(':memory_type', $memoryType, SQLITE3_TEXT);
        }

        $result = $stmt->execute();
        $similarities = [];

        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $vector = json_decode($row['embedding'], true);
            if (!$vector) continue;

            $similarity = $this->cosineSimilarity($queryEmbedding, $vector);
            
            if ($similarity >= $minSimilarity) {
                $similarities[] = [
                    'id' => $row['id'],
                    'content' => $row['content'],
                    'memory_type' => $row['memory_type'],
                    'source_file' => $row['source_file'],
                    'similarity' => $similarity,
                ];
            }
        }

        usort($similarities, fn($a, $b) => $b['similarity'] <=> $a['similarity']);

        return array_slice($similarities, 0, $limit);
    }

    public function searchEpisodicMemories(
        array $queryEmbedding,
        ?int $userId = null,
        int $limit = 3,
        float $minSimilarity = 0.75
    ): array {
        if (!$this->db) {
            return [];
        }

        $sql = 'SELECT id, fact, context FROM episodic_memory';

        if ($userId) {
            $sql .= ' WHERE user_id = :user_id';
        }

        $stmt = $this->db->prepare($sql);
        
        if ($userId) {
            $stmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
        }

        $result = $stmt->execute();
        $similarities = [];

        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $embedStmt = $this->db->prepare('SELECT embedding FROM episodic_memory WHERE id = :id');
            $embedStmt->bindValue(':id', $row['id'], SQLITE3_INTEGER);
            $embedResult = $embedStmt->execute();
            $embedRow = $embedResult->fetchArray(SQLITE3_ASSOC);
            
            if (!$embedRow) continue;
            
            $vector = json_decode($embedRow['embedding'], true);
            if (!$vector) continue;

            $similarity = $this->cosineSimilarity($queryEmbedding, $vector);
            
            if ($similarity >= $minSimilarity) {
                $similarities[] = [
                    'id' => $row['id'],
                    'fact' => $row['fact'],
                    'context' => $row['context'],
                    'similarity' => $similarity,
                ];
            }
        }

        usort($similarities, fn($a, $b) => $b['similarity'] <=> $a['similarity']);

        return array_slice($similarities, 0, $limit);
    }

    private function cosineSimilarity(array $a, array $b): float {
        $dotProduct = 0;
        $normA = 0;
        $normB = 0;

        for ($i = 0; $i < count($a); $i++) {
            $dotProduct += $a[$i] * $b[$i];
            $normA += $a[$i] ** 2;
            $normB += $b[$i] ** 2;
        }

        if ($normA == 0 || $normB == 0) {
            return 0;
        }

        return $dotProduct / (sqrt($normA) * sqrt($normB));
    }

    public function clearMemory(string $memoryType): bool {
        if (!$this->db) {
            return false;
        }

        try {
            $stmt = $this->db->prepare('DELETE FROM memory_vectors WHERE memory_type = :memory_type');
            $stmt->bindValue(':memory_type', $memoryType, SQLITE3_TEXT);
            $stmt->execute();
            return true;
        } catch (\Exception $e) {
            error_log('VectorStore error: ' . $e->getMessage());
            return false;
        }
    }

    public function pruneMemoryType(string $memoryType, int $keepLatest = 60): bool {
        if (!$this->db) {
            return false;
        }

        if ($keepLatest <= 0) {
            return $this->clearMemory($memoryType);
        }

        try {
            $stmt = $this->db->prepare('
                DELETE FROM memory_vectors
                WHERE memory_type = :memory_type
                  AND id NOT IN (
                    SELECT id
                    FROM memory_vectors
                    WHERE memory_type = :memory_type_inner
                    ORDER BY created_at DESC, id DESC
                    LIMIT :keep_latest
                  )
            ');
            $stmt->bindValue(':memory_type', $memoryType, SQLITE3_TEXT);
            $stmt->bindValue(':memory_type_inner', $memoryType, SQLITE3_TEXT);
            $stmt->bindValue(':keep_latest', $keepLatest, SQLITE3_INTEGER);
            $stmt->execute();
            return true;
        } catch (\Exception $e) {
            error_log('VectorStore prune error: ' . $e->getMessage());
            return false;
        }
    }

    public function isFileLoaded(string $filePath, string $fileHash): bool {
        if (!$this->db) {
            return false;
        }

        try {
            $stmt = $this->db->prepare('SELECT file_hash FROM loaded_files WHERE file_path = :file_path');
            $stmt->bindValue(':file_path', $filePath, SQLITE3_TEXT);
            $result = $stmt->execute();
            $row = $result->fetchArray(SQLITE3_ASSOC);
            return $row && $row['file_hash'] === $fileHash;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function markFileLoaded(string $filePath, string $fileHash): bool {
        if (!$this->db) {
            return false;
        }

        try {
            $stmt = $this->db->prepare('
                INSERT OR REPLACE INTO loaded_files (file_path, file_hash, loaded_at)
                VALUES (:file_path, :file_hash, CURRENT_TIMESTAMP)
            ');
            $stmt->bindValue(':file_path', $filePath, SQLITE3_TEXT);
            $stmt->bindValue(':file_hash', $fileHash, SQLITE3_TEXT);
            $stmt->execute();
            return true;
        } catch (\Exception $e) {
            error_log('VectorStore error: ' . $e->getMessage());
            return false;
        }
    }

    public function getFileHash(string $filePath): string {
        return hash_file('sha256', $filePath);
    }

    public function getStats(): array {
        $stats = [
            'identity_vectors' => 0,
            'reference_vectors' => 0,
            'episodic_memories' => 0,
        ];

        if (!$this->db) {
            return $stats;
        }

        try {
            $result = $this->db->query('
                SELECT memory_type, COUNT(*) as count 
                FROM memory_vectors 
                GROUP BY memory_type
            ');

            while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                $stats[$row['memory_type'] . '_vectors'] = $row['count'];
            }

            $result = $this->db->query('SELECT COUNT(*) as count FROM episodic_memory');
            $row = $result->fetchArray(SQLITE3_ASSOC);
            $stats['episodic_memories'] = $row['count'];
        } catch (\Exception $e) {
            error_log('VectorStore stats error: ' . $e->getMessage());
        }

        return $stats;
    }

    private function getEmbeddingRequestConfig(): array|WP_Error {
        $settings = new \Levi\Agent\Admin\SettingsPage();
        $provider = $settings->getProvider();
        $apiKey = $settings->getApiKeyForProvider($provider);

        if (!$apiKey) {
            return new WP_Error('no_api_key', sprintf('Kein API-Key für den ausgewählten Provider (%s) hinterlegt.', $provider));
        }

        if ($provider === 'anthropic') {
            return new WP_Error(
                'embedding_provider_unsupported',
                'Embeddings werden aktuell für OpenRouter und OpenAI unterstützt. Bitte Provider auf OpenRouter/OpenAI stellen oder Embeddings separat konfigurieren.'
            );
        }

        $endpoint = $provider === 'openrouter'
            ? 'https://openrouter.ai/api/v1/embeddings'
            : 'https://api.openai.com/v1/embeddings';
        $model = $provider === 'openrouter'
            ? 'openai/text-embedding-3-small'
            : $this->embeddingModel;

        $headers = [
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ];
        if ($provider === 'openrouter') {
            $headers['HTTP-Referer'] = home_url('/');
            $headers['X-Title'] = 'Levi AI Agent';
        }

        return [
            'provider' => $provider,
            'endpoint' => $endpoint,
            'model' => $model,
            'headers' => $headers,
        ];
    }

    public function __destruct() {
        if ($this->db) {
            $this->db->close();
        }
    }
}
